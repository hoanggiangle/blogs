# Sendo Internal APIS definition

## [Usage](https://gitlab.sendo.vn/protobuf/internal-apis-go/wikis/home)

