// Sendo Service Discovery
//
// Provide api to join Sendo micro service cluster
package ssd
