# Sendo Golang SDK 2
View docucument and guides at [Sendo Golang SDK 2.x](https://sendovn.atlassian.net/wiki/spaces/DC1/pages/746849936/Sendo+Golang+SDK+V2)

For SDK v1: [Golang SDK](https://gitlab.sendo.vn/core/golang-sdk/wikis/home)
