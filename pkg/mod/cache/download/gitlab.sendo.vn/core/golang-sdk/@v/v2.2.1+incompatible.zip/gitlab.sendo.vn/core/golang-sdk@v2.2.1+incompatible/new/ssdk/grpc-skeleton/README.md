Service {{ .ServiceName }}
===============

## Setup & Run

Check document and guide at [Sendo Golang SDK 2](https://sendovn.atlassian.net/wiki/spaces/SA/pages/735739905/Golang+Sendo+SDK+v2.x)
